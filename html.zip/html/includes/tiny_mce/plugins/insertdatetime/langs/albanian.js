// UK lang variables

tinyMCELang['lang_insertdate_desc'] = 'Insert date';
tinyMCELang['lang_inserttime_desc'] = 'Insert time';
tinyMCELang['lang_inserttime_months_long'] = new Array("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December");
tinyMCELang['lang_inserttime_months_short'] = new Array("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec");
tinyMCELang['lang_inserttime_day_long'] = new Array("Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday");
tinyMCELang['lang_inserttime_day_short'] = new Array("Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun");
