// DE lang variables 

tinyMCELang['lang_print_desc'] = 'Drucken';
