// UK lang variables

tinyMCELang['lang_print_desc'] = 'Print';
