// French lang variables by Laurent Dran

tinyMCELang['lang_preview_desc'] = 'Pr&eacute;visualisation';
