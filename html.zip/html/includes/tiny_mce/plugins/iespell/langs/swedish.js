// SE lang variables

tinyMCELang['lang_iespell_desc'] = 'K�r r�ttstavningskontroll';
tinyMCELang['lang_iespell_download'] = "ieSpell verkar inte vara installerad. Klicka OK f&ouml;r att ladda hem."
