// UK lang variables

tinyMCELang['lang_searchreplace_search_desc'] = 'Find';
tinyMCELang['lang_searchreplace_searchnext_desc'] = 'Find again';
tinyMCELang['lang_searchreplace_replace_desc'] = 'Find/Replace';
tinyMCELang['lang_searchreplace_notfound'] = 'The search has been compleated. The search string could not be found.';
tinyMCELang['lang_searchreplace_search_title'] = 'Find';
tinyMCELang['lang_searchreplace_replace_title'] = 'Find/Replace';
tinyMCELang['lang_searchreplace_allreplaced'] = 'All occurrences of the search string was replaced.';
tinyMCELang['lang_searchreplace_findwhat'] = 'Find what';
tinyMCELang['lang_searchreplace_replacewith'] = 'Replace with';
tinyMCELang['lang_searchreplace_direction'] = 'Direction';
tinyMCELang['lang_searchreplace_up'] = 'Up';
tinyMCELang['lang_searchreplace_down'] = 'Down';
tinyMCELang['lang_searchreplace_case'] = 'Match case';
tinyMCELang['lang_searchreplace_findnext'] = 'Find&nbsp;next';
tinyMCELang['lang_searchreplace_replace'] = 'Replace';
tinyMCELang['lang_searchreplace_replaceall'] = 'Replace&nbsp;all';
tinyMCELang['lang_searchreplace_cancel'] = 'Cancel';
