// UK lang variables

tinyMCELang['lang_insert_flash']      = 'Insert / edit Flash Movie';
tinyMCELang['lang_insert_flash_file'] = 'Flash-File (.swf)';
tinyMCELang['lang_insert_flash_size'] = 'Size';
tinyMCELang['lang_insert_flash_list'] = 'Flash files';
