// SE lang variables

tinyMCELang['lang_insert_flash']      = 'Skapa/uppdatera flash-film';
tinyMCELang['lang_insert_flash_file'] = 'Flash-film (.swf)';
tinyMCELang['lang_insert_flash_size'] = 'Storlek';
tinyMCELang['lang_insert_flash_list'] = 'Flash-filer';
