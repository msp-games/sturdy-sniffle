// French lang variables by Laurent Dran

tinyMCELang['lang_insert_flash']      = 'Ins&eacute;rer / &eacute;diter une animation Flash';
tinyMCELang['lang_insert_flash_file'] = 'Fichier-Flash (.swf)';
tinyMCELang['lang_insert_flash_size'] = 'Taille';
tinyMCELang['lang_insert_flash_list'] = 'Fichiers Flash';
