// French lang variables by Laurent Dran

tinyMCELang['lang_insert_emotions_title'] = 'Ins&egrave;rer un &eacute;moticon';
tinyMCELang['lang_emotions_desc'] = '&Eacute;moticons';

